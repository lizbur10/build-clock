import React, { Component } from "react";

export default class componentName extends Component {
  render() {
    return (
      <>
        <button onClick={this.props.addBtnFnc}>Add</button>
      </>
    );
  }
}
